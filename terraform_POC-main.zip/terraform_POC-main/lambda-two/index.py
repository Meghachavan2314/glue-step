import random
def handler(event,context):
    return random.randint(5, 100)