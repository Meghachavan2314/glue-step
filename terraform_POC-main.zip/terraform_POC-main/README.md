# Terraform-POC

![image](https://user-images.githubusercontent.com/20047900/182855872-89f66aac-7f5a-405f-bd07-58845e5eec99.png)
